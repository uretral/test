<?
$MESS['USERS_LIST_ORDER_BY_FIELD'] = 'Поле сортировки';
$MESS['USERS_LIST_ORDER_BY_DIRECTION'] = 'Направление сортировки';
$MESS['USERS_LIST_ORDER_BY_ID'] = 'ID пользователя';
$MESS['USERS_LIST_ORDER_BY_LOGIN'] = 'Логин пользователя';
$MESS['USERS_LIST_ORDER_BY_EMAIL'] = 'Email пользователя';
$MESS['USERS_LIST_ORDER_BY_NAME'] = 'Имя пользователя';
$MESS['USERS_LIST_SHOW_NAV'] = 'Постраничная навигация';
$MESS['USERS_LIST_PARAMETERS_COUNT'] = 'Количество элементов';
$MESS['USERS_LIST_SORT_ASC'] = 'По возрастанию';
$MESS['USERS_LIST_SORT_DESC'] = 'По убыванию';
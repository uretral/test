<?
$MESS['USERS_LIST_DESCRIPTION_NAME'] = 'Кастомный компонент';
$MESS['USERS_LIST_DESCRIPTION_DESCRIPTION'] = 'Компанент для отображения списка пользователей';
$MESS['USERS_LIST_DESCRIPTION_GROUP'] = 'Тестовые';
$MESS['USERS_LIST_DESCRIPTION_DIR'] = 'Кастомный компонент users.list';
?>